from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from .views import Create_queez,Score_Cal

urlpatterns = [
    path('createqueez/',Create_queez),
    path('ScoreCal/',Score_Cal)
    
]
