from django.shortcuts import render
import json
from django.http.response import HttpResponse, JsonResponse
from .models import Answers,Question,User,Category_Question,Queez
from django.views.decorators.csrf import csrf_exempt
import random

correct_answer_list=[]
id=[]
@csrf_exempt
def Create_queez(request):#create user Then create quiz
    if request.method == "POST":
        data =json.loads(request.body)
        if "username" not in data or "password" not in data:
            return JsonResponse({"status": "error", "msg": "Enter username and password:"}, status=403)
        queez_user = data.get("username", "")
        queez_pass = data.get("password", "")
        
        if not User.objects.filter(username=queez_user).exists():
            user=User.objects.create(username=queez_user, password=queez_pass)
        else:
            user=User.objects.get(username=queez_user)
        correct_answer_list.clear()
        quiz={}
        cat=Category_Question.objects.all()
        for c in cat:
            quiz[c.cat_name]={}
            questions=list(c.category.all())
            rq=random.sample(questions,2)
            for q in rq:
                ans=list(q.question.values_list('ans_alpha','ans_title'))
                quiz[c.cat_name][q.que_title]=ans
                correct_answer_list.append(q.corect_ans)
        q=Queez.objects.create(username=user,queez=quiz)
        id.append(q.id)
        return JsonResponse({"status": "successful", "msg": "user created successfully.","quize":quiz}, status=201)  
    else:
        return JsonResponse({"status": "error", "msg": "method bayad POST bashe"}, status=403)

@csrf_exempt
def Score_Cal(request):
    if request.method=='POST':
        answers=json.loads(request.body)
        len_answers=len(answers)
        user_answers_list=[]
        score=[]
        for i in answers:
            user_answers_list.append(answers.get(i))
        result=0
        for i,j in zip(correct_answer_list,user_answers_list):
            if i==j:
                result+=1

        score.append(result)
        qinstance=Queez.objects.get(id=id[-1])
        qinstance.score=result
        qinstance.save()
        return JsonResponse({"status":"successful","your answers":user_answers_list,"correct answers":correct_answer_list,"score":score},status=201)

    
    


def Create_Queez(request):
    pass







