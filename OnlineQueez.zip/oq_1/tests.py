from django.test import TestCase
from  oq_1.models import Question
qs=Question.objects.all()
for i in qs:
    print(i)

