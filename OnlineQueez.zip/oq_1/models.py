from django.core.exceptions import SuspiciousOperation
from django.db import models
from django.db.models.deletion import CASCADE, SET_NULL
from django.db.models.fields import CharField
from django.db.models.fields.related import ForeignKey

# Create your models here.
class Category_Question(models.Model):
    cat_name=models.CharField(max_length=40)

    def __str__(self):
        return self.cat_name

    
class Question(models.Model):
    correct_ans_choices=[
        ('الف','الف'),
        ('ب','ب'),
        ('ج','ج'),
        ('د','د')
    ]
    que_title=models.TextField()
    cat_id=models.ForeignKey(Category_Question,on_delete=CASCADE,related_name='category')
    corect_ans=models.CharField(max_length=5,null=True,choices=correct_ans_choices)


    def __str__(self):
        return self.que_title


class User(models.Model):
    username=models.CharField(primary_key=True,max_length=10)
    password=models.CharField(max_length=20)
    

    def __str__(self):
        return f"{self.username}"


class Answers(models.Model):
    ans_alpha_choices=[
        ('الف','الف'),
        ('ب','ب'),
        ('ج','ج'),
        ('د','د')
    ]
    ans_title=models.TextField()
    que_id=models.ForeignKey(Question,on_delete=CASCADE,related_name='question')
    ans_alpha=models.CharField(max_length=5,null=True,choices=ans_alpha_choices)

    def __str__(self):
        return self.ans_title


class Queez(models.Model):
    date=models.DateTimeField(auto_now_add=True)
    score=models.IntegerField(null=True)
    username=ForeignKey(User,on_delete=SET_NULL,null=True,related_name='user')
    queez=models.JSONField(null=True)

    def __str__(self):
        return f"Date: {self.date} , Score:{self.score} , user:{self.username}"

