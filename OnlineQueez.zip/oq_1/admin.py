from django.contrib import admin

from oq_1.models import Question,Category_Question,Answers,Queez,User

admin.site.register(Question)
admin.site.register(Category_Question)
admin.site.register(Answers)
admin.site.register(Queez)
admin.site.register(User)